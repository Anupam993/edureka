---
name: Feature request
about: Suggest an idea for this project

---

### Motivation

Why is this feature required? What problems does it solve?

### Proposed solution

An ideal solution for the above problems.

### Additional context

Add any other context, screenshots, or reference links about the feature request here.
