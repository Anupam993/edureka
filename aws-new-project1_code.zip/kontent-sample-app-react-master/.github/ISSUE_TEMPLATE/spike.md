---
name: Spike
about: Suggest an analysis of a problem

---

### Expected result

What do we want to explore and why? Which questions do we want to answer with this spike?

### Additional context

Add any other context or guidelines here.

### Resources

* URL
